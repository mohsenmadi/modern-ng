import { OlsBannerComponent } from './ols-banners.component';
import { OlsBannerService } from './ols-banners.service';
import { Router, RoutesRecognized } from '@angular/router';
import { Subject } from 'rxjs';

describe('OlsBannerComponent', () => {
  let component: OlsBannerComponent;
  let mockBannerService: Partial<OlsBannerService>;
  let mockRouter: Subject<RoutesRecognized>;

  beforeEach(() => {
    mockBannerService = {};

    mockRouter = new Subject<RoutesRecognized>();

    const mockRouterInstance: Partial<Router> = {
      events: mockRouter.asObservable(),
    };

    component = new OlsBannerComponent(mockBannerService as OlsBannerService, mockRouterInstance as Router);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
