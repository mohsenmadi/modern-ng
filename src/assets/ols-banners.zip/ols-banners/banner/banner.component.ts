import { Component, Input } from '@angular/core';
import { OlsBanner } from '../ols-banners.model';
import { AlertModule } from '@xdsystems/coop-library-angular';

@Component({
  selector: 'coop-banner',
  templateUrl: './banner.component.html',
  imports: [AlertModule],
  standalone: true,
})
export class BannerComponent {
  @Input() bannerDetails!: OlsBanner;
}
