import { OlsBanner } from '../ols-banners.model';
import { BannerComponent } from './banner.component';

describe('BannerComponent', () => {
  let component: BannerComponent;

  beforeEach(() => {
    component = new BannerComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should correctly set bannerDetails input', () => {
    const bannerDetails: OlsBanner = {
      Title: 'Test Title',
      Status: 'danger',
      Type: 'primary',
      Is_Closable: '1',
      Description: 'Test Description',
      TemplateID: '',
      Order: '',
      Location0: '',
      Location1: '',
      Location2: '',
      Location3: '',
      Location4: '',
      Location5: '',
    };

    component.bannerDetails = bannerDetails;
    // It simply checks if the bannerDetails input property is set to the bannerDetails object
    expect(component.bannerDetails).toEqual(bannerDetails);
  });
});
