import { StatusAttribute, StyleAttribute } from '@xdsystems/coop-library-angular';

export interface OlsBanner {
  TemplateID: string;
  Order: string;
  Title: string;
  Description: string;
  Status: StatusAttribute;
  Type: StyleAttribute;
  Is_Closable: string;
  Location0: string;
  Location1: string;
  Location2: string;
  Location3: string;
  Location4: string;
  Location5: string;
}

export interface BannerState {
  banners: OlsBanner[];
  bannersByLocationMap: Record<string, number[]>;
  globalBanners: Set<number>;
}

export const equalsIgnoreCase = (s1: string, s2: string) => s1.toLowerCase() === s2.toLowerCase();

export const GLOBAL = 'global';
