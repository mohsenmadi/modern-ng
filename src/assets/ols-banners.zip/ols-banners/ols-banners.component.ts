import { Component } from '@angular/core';
import { OlsBannerService } from './ols-banners.service';
import { AsyncPipe, JsonPipe, NgForOf } from '@angular/common';
import { BannerComponent } from './banner/banner.component';
import { Router, RoutesRecognized } from '@angular/router';

@Component({
  selector: 'coop-ols-banners',
  templateUrl: './ols-banners.component.html',
  imports: [NgForOf, BannerComponent, AsyncPipe, JsonPipe],
  standalone: true,
  providers: [OlsBannerService],
})
export class OlsBannerComponent {
  location = '';

  constructor(
    public bannerService: OlsBannerService,
    private router: Router
  ) {
    router.events.subscribe((event) => {
      if (event instanceof RoutesRecognized) {
        this.location = event.state.root.firstChild?.data?.bannerPage;
      }
    });
  }
}
