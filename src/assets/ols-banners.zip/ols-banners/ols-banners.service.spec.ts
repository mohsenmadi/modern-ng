import { of } from 'rxjs';
import { LanguageService } from '../system';
import { BannerState, OlsBanner } from './ols-banners.model';
import { OlsBannerService } from './ols-banners.service';
import { take } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

describe('OlsBannerService', () => {
  let service: OlsBannerService;
  let mockHttpClient: { get: jest.Mock };

  beforeEach(() => {
    const LanguageService = {
      currentLang$: of('en'),
    } as LanguageService;

    mockHttpClient = {
      get: jest.fn(),
    };
    //adding unknown to for missing the  properties from type 'HttpClient'
    service = new OlsBannerService(mockHttpClient as unknown as HttpClient, LanguageService, {} as any);

    const initialState: BannerState = {
      banners: [],
      bannersByLocationMap: {},
      globalBanners: new Set<number>(),
    };
    service.setState(initialState);
  });

  describe('globalBanners$', () => {
    it('should select and return global banners', (done) => {
      const mockData: OlsBanner[] = [];
      const globalBannerIndeices = new Set<number>([0, 1]);
      service.setState({
        banners: mockData,
        bannersByLocationMap: {},
        globalBanners: globalBannerIndeices,
      });

      service.globalBanners$.subscribe((globalBanners) => {
        expect(globalBanners).toEqual([mockData[0], mockData[1]]);
        done();
      });
    });
  });

  describe('bannersByLocation$', () => {
    it('should select and return banners by location', (done) => {
      const mockData: OlsBanner[] = [];
      service.setState({
        banners: mockData,
        bannersByLocationMap: { location1: [0, 1] },
        globalBanners: new Set<number>(),
      });

      service.bannersByLocation$('location1').subscribe((banners) => {
        expect(banners).toEqual([mockData[0], mockData[1]]);
        done();
      });
    });
  });

  describe('updateGlobalBanners', () => {
    it('should update global banners array', (done) => {
      const mockData: OlsBanner[] = [];
      const globalBannerIndeices = new Set<number>([0]);
      service.setState({
        banners: mockData,
        bannersByLocationMap: { location1: [0, 1] },
        globalBanners: globalBannerIndeices,
      });

      service.updateGlobalBanners(1);

      service.state$.subscribe((newState) => {
        expect(newState.globalBanners).toEqual(globalBannerIndeices);
        done();
      });
    });
  });

  describe('getLocationIdxValue', () => {
    it('should return the value of a specific location index', () => {
      const banner: OlsBanner = {
        TemplateID: '0',
        Order: '0',
        Title: 'Title',
        Description: 'Description',
        Location0: 'location0',
        Location1: 'location1',
        Status: 'danger',
        Type: 'primary',
        Is_Closable: '',
        Location2: '',
        Location3: '',
        Location4: '',
        Location5: '',
      };

      const value = service.getLocationIdxValue(banner, 1);

      expect(value).toBe('location1');
    });
  });

  describe('bannerIsGlobal', () => {
    it('should return true and update globalBanners for global banner', async () => {
      const globalBanner: OlsBanner = {
        Location0: 'global',
        TemplateID: '',
        Order: '',
        Title: '',
        Description: '',
        Status: 'danger',
        Type: 'primary',
        Is_Closable: '',
        Location1: '',
        Location2: '',
        Location3: '',
        Location4: '',
        Location5: '',
      };

      const initialState: BannerState = {
        banners: [globalBanner],
        bannersByLocationMap: {},
        globalBanners: new Set<number>(),
      };
      service.setState(initialState);

      const result = service.bannerIsGlobal(globalBanner, 0);

      expect(result).toBeTruthy();

      await service.globalBanners$.pipe(take(1)).toPromise();

      let emittedGlobalBanners: OlsBanner[] = [];
      service.globalBanners$.pipe(take(1)).subscribe((banners) => {
        emittedGlobalBanners = Array.from(banners);
      });
      const containsGlobalBanner = emittedGlobalBanners.some((banner) => banner.Location0 === 'global');
      expect(containsGlobalBanner).toBe(true);
    });

    it('should return false for non-global banner', async () => {
      const nonGlobalBanner: OlsBanner = {
        Location0: 'sign-in',
        TemplateID: '',
        Order: '',
        Title: '',
        Description: '',
        Status: 'danger',
        Type: 'primary',
        Is_Closable: '',
        Location1: '',
        Location2: '',
        Location3: '',
        Location4: '',
        Location5: '',
      };

      const initialState: BannerState = {
        banners: [nonGlobalBanner],
        bannersByLocationMap: {},
        globalBanners: new Set<number>(),
      };
      service.setState(initialState);

      const result = service.bannerIsGlobal(nonGlobalBanner, 0);

      expect(result).toBeFalsy();

      // Wait for the next asynchronous operation to complete
      await service.globalBanners$.pipe(take(1)).toPromise();

      let emittedGlobalBanners: OlsBanner[] = [];
      service.globalBanners$.pipe(take(1)).subscribe((banners) => {
        emittedGlobalBanners = Array.from(banners);
      });

      const containsGlobalBanner = emittedGlobalBanners.some((banner) => banner.Location0 === 'global');
      expect(containsGlobalBanner).toBe(false);
    });
  });

  describe('bannerIsByLocation', () => {
    it('should update bannersByLocationMap for banner with locations', () => {
      const banner: OlsBanner = {
        TemplateID: '0',
        Order: '0',
        Title: 'Title',
        Description: 'Description',
        // Fill in the rest of the properties
        // ...
        Location0: 'location0',
        Location1: 'location1',
        Status: 'danger',
        Type: 'primary',
        Is_Closable: '',
        Location2: '',
        Location3: '',
        Location4: '',
        Location5: '',
      };
      const map: Record<string, number[]> = {};

      service.bannerIsByLocation(banner, 1, map);

      expect(map).toEqual({ location0: [1], location1: [1] });
    });

    it('should not update bannersByLocationMap for banner without locations', () => {
      const banner: OlsBanner = {
        TemplateID: '0',
        Order: '0',
        Title: 'Title',
        Description: 'Description',
        Location0: '',
        Location1: '',
        Status: 'danger',
        Type: 'primary',
        Is_Closable: '',
        Location2: '',
        Location3: '',
        Location4: '',
        Location5: '',
      };
      const map: Record<string, number[]> = {};

      service.bannerIsByLocation(banner, 1, map);

      expect(map).toEqual({});
    });
  });
});
