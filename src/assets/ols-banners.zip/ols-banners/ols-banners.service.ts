import { of, Subscription } from 'rxjs';
import { AppConfigService, LanguageService } from '../system';
import { HttpClient } from '@angular/common/http';
import { BannerState, equalsIgnoreCase, GLOBAL, OlsBanner } from './ols-banners.model';
import { catchError, distinctUntilChanged, map, take } from 'rxjs/operators';
import { Injectable, OnDestroy } from '@angular/core';
import { ComponentStore } from '@ngrx/component-store';

const defaultState: BannerState = {
  banners: [],
  bannersByLocationMap: {},
  globalBanners: new Set<number>(),
};

@Injectable()
export class OlsBannerService extends ComponentStore<BannerState> implements OnDestroy {
  subscription: Subscription = new Subscription();

  constructor(
    private http: HttpClient,
    private languageService: LanguageService,
    private appConfigService: AppConfigService
  ) {
    super(defaultState);
    this.subscription = languageService.currentLang$.pipe(distinctUntilChanged()).subscribe((lang) => {
      this.loadBanners(this.constructUrl(lang), this.http);
    });
  }

  constructUrl = (lang: string) => {
    const bannerConfiguration = this.appConfigService.getAppConfig().olsBanners.sitecoreConfig;
    const language = lang === 'fr' ? 'fr-CA' : 'en';
    return `${bannerConfiguration.url}/${bannerConfiguration.appContextContentId}?language=${language}`;
  };

  readonly loadBanners = (URL: string, http: HttpClient) => {
    http
      .get<OlsBanner[]>(URL)
      .pipe(
        map((banners) =>
          banners.filter((banner) => equalsIgnoreCase(banner.TemplateID, this.appConfigService.getAppConfig().olsBanners.templateID))
        ),
        map((banners) => banners.sort((a, b) => (a.Order > b.Order ? 1 : -1))),
        take(1),
        catchError((error) => of(error))
      )
      .subscribe((banners) => {
        this.prepBannerStateProps(banners);
      });
  };

  globalBanners$ = this.select((state) => Array.from(state.globalBanners).map((index: number) => state.banners[index]));

  bannersByLocation$ = (location: string) =>
    this.select((state) => state.bannersByLocationMap[location]?.map((index: number) => state.banners[index]));

  updateGlobalBanners = (bannerIndex: number) => {
    this.state$.pipe(take(1)).subscribe((state) => state.globalBanners.add(bannerIndex));
  };

  getLocationIdxValue = (banner: OlsBanner, i: number) => (banner as any)[`Location${i}`].trim().toLowerCase();

  bannerIsGlobal = (banner: OlsBanner, bannerIdx: number) => {
    for (let i = 0; i <= 5; i++) {
      if (this.getLocationIdxValue(banner, i) === GLOBAL) {
        this.updateGlobalBanners(bannerIdx);
        return true;
      }
    }
    return false;
  };

  bannerIsByLocation = (banner: OlsBanner, bannerIdx: number, map: Record<string, number[]>) =>
    [0, 1, 2, 3, 4, 5]
      .map((index) => this.getLocationIdxValue(banner, index))
      .filter((location) => !!location.trim())
      .map((location) => location.trim().toLowerCase())
      .forEach((location) => {
        if (!map[location]) {
          map[location] = [];
        }
        map[location].push(bannerIdx);
      });

  private prepBannerStateProps(banners: OlsBanner[]): void {
    const bannersByLocationMap: Record<string, number[]> = {};
    for (let i = 0; i < banners.length; i++) {
      if (!this.bannerIsGlobal(banners[i], i)) {
        this.bannerIsByLocation(banners[i], i, bannersByLocationMap);
      }
    }
    this.setState((state: BannerState) => ({ ...state, banners, bannersByLocationMap }));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
