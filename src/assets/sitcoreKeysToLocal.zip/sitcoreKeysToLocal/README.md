# Angular Project

This project is an Angular application that aims to take in sitecore keys and format them to be able to be used in application.

## Installation

To run this project locally, follow these steps:

1. Ensure you have [Node.js](https://nodejs.org) installed on your machine.
2. Navigate to the project directory: `cd sitecore-to-json`.
3. Install the project dependencies by running `npm i`.


## Usage

To transform a sitecore keyset into a JSON i18n file format, run:

 `npm run transform <sitecore-file.json> > <target-file.json>` 
 
This will transform the sitecore file and redirect the output into the target file with a name of your choosing.

To merge a transformed sitecore file onto a local one, run:

 `npm run merge <file-1.json> <file-2.json> > <target-file.json>`

The resulting file - <target-file.json> - will have its entries as follows:

1. entries exclusively in <file-1.json> will be added as is
2. entries exclusively in <file-2.json> will be added as is
3. entries with same keys in both files will have values in <file-1.json> overwrite those of <file-2.json>

As an example, run the following commands and see the expected result (parts in brackets [ ] are optional, depending if you want to redirect the output into a file):

`npm run transform sitecore-entry.json [ > transformed.json` ]

`npm run merge sample-sitecore.json sample.local [ > merged.json` ]
