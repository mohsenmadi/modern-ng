/* eslint-disable @typescript-eslint/no-var-requires */
const program = require('commander');
const fs = require('fs');

function mergeJsonFiles(file1: string, file2: string): void {
  const json1 = JSON.parse(fs.readFileSync(file1, 'utf8'));
  const json2 = JSON.parse(fs.readFileSync(file2, 'utf8'));

  const mergedJson = mergeObjects({}, json1, json2);

  console.log(JSON.stringify(mergedJson, null, 2));
}

function mergeObjects(result: any, obj1: any, obj2: any): any {
  for (const key in obj1) {
    if (typeof obj1[key] === 'object' && !Array.isArray(obj1[key])) {
      if (obj2.hasOwnProperty(key) && typeof obj2[key] === 'object' && !Array.isArray(obj2[key])) {
        result[key] = mergeObjects({}, obj1[key], obj2[key]);
      } else {
        result[key] = obj1[key];
      }
    } else {
      result[key] = obj1[key];
    }
  }

  for (const key in obj2) {
    if (typeof obj2[key] === 'object' && !Array.isArray(obj2[key])) {
      if (!result.hasOwnProperty(key)) {
        result[key] = obj2[key];
      }
    } else if (!result.hasOwnProperty(key)) {
        result[key] = obj2[key];
      }
  }

  return result;
}

type KeyMap = Record<string, string | Record<string, any>> | string;
const map: KeyMap = {};
const buildJsonMap = (map: Record<string, any>, keys: string[], value: string) => {
  if (keys.length > 1) {
    if (!map[keys[0]]) {
      const valueMap = {};
      map[keys[0]] = valueMap;
      buildJsonMap(valueMap, keys.slice(1), value);
    } else {
      buildJsonMap(map[keys[0]], keys.slice(1), value);
    }
  } else {
    map[keys[0]] = value;
  }
};

const preprocessJsonKeys = (entries: any) => {
  for (const key in entries) {
    buildJsonMap(map, key.split('__'), entries[key]);
  }
  console.log(JSON.stringify(map, null, 2));
};

// logic below for opening files, converting contents into
// a JSON object and passing to key convertor above

const parseFile = (file: any) => {
  const entries = fs.readFileSync(file, 'utf8');
  preprocessJsonKeys(JSON.parse(entries));
};

const compareFile = (file1: any, file2: any) => {
  mergeJsonFiles(file1, file2);
};

program.version('1.0.0').description('convert keys');

program
  .command('transform')
  .alias('t')
  .description('transform sitecore keys to json objects')
  .action((file: any) => {
    parseFile(file);
  });

program
  .command('merge')
  .alias('m')
  .description('merge sitecore onto local json to give union of both')
  .action((localFile: any, sitecoreFile: any) => {
    compareFile(localFile, sitecoreFile);
  });

program.parse(process.argv);
